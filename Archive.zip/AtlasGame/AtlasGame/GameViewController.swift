//
//  GameViewController.swift
//  AtlasGame
//
//  Created by Aadit Kapoor on 6/6/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit
import Alamofire
import Toaster
import SwiftSpinner
import Speech
import Chirp

extension String {
    
    var length: Int {
        return self.characters.count
    }
    
    subscript (i: Int) -> String {
        return self[Range(i ..< i + 1)]
    }
    
    func substring(from: Int) -> String {
        return self[Range(min(from, length) ..< length)]
    }
    
    func substring(to: Int) -> String {
        return self[Range(0 ..< max(0, to))]
    }
    
    subscript (r: Range<Int>) -> String {
        let range = Range(uncheckedBounds: (lower: max(0, min(length, r.lowerBound)),
                                            upper: min(length, max(0, r.upperBound))))
        let start = index(startIndex, offsetBy: range.lowerBound)
        let end = index(start, offsetBy: range.upperBound - range.lowerBound)
        return self[Range(start ..< end)]
    }
    
}

class GameViewController: UIViewController, SFSpeechRecognizerDelegate {
    
    
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "en-US")) 

    
    @IBOutlet weak var timeLabel: UILabel!
    var isDataLoaded:Bool = false
    var countriesData:Array<String> = []
    var loaded:Bool = false
    
    let interval = 1.0
    
    var country:String!
    
    var timer:Timer!
    var timer_counter=0
    
    @IBOutlet weak var computerChance: UILabel!
    @IBOutlet weak var controlsStackView: UIStackView!
    @IBOutlet weak var userChance: UILabel!
    
    
    var userEnteredText:String!
    
    
    func speakCountry(country:String) {
        let speech = AVSpeechSynthesizer()
        let utt = AVSpeechUtterance(string: country)
        speech.speak(utt)
    }
    
    func checkIfExists(name:String) -> Bool {
        if countriesData.contains(name) {
            return true
        }
        else {
            return false
        }
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        controlsStackView.isHidden = true
        SwiftSpinner.show("Loading Countries")
        
        print(self.countriesData)
        
        if self.countriesData.count == 0 {
            requestToLoadData()
        }
        
        for i in self.countriesData {
            print (i)
        }
        
        
    }
    
    func createTimer() {
        timer = Timer.scheduledTimer(timeInterval: interval, target: self, selector: #selector(update), userInfo: nil, repeats: true)
    }
    
    func update() {
        if timer_counter == 20 {
            timer.invalidate()
            self.timer_counter = 0
            
            
            self.dismissGame()
            createFinishAlert(message: "Game Over!")
            print("Stopped!")
        }
        else {
            
            timer_counter+=1
            
            timeLabel.text = "Time: \(timer_counter)"
        }
        
        
    }
    
    
    func deleteCountry(country:String) {
        print ("deleted \(country)")
        self.countriesData.remove(at: countriesData.index(of: country)!)
    }
    
    func createAlertWithText() {
        let alert = UIAlertController(title: "Enter country", message: "Your Turn", preferredStyle: .alert)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissGame))
        
        
        let saveAction = UIAlertAction(title: "Enter", style: UIAlertActionStyle.default, handler: {alertArg -> Void in
            
            self.userEnteredText = String(alert.textFields![0].text!)
            
            
            print (self.userEnteredText)
            print(self.country)

                       
            if self.checkIfExists(name: self.userEnteredText) {
                
                // Thinking ability (Code changed)
                var x = CountryThinker(data: self.countriesData)
                var a = x.validateEnteredCountry(beforeCountry: self.country, enteredCountry: self.userEnteredText)
                if a != nil {
                    self.userChance.text = "You say \(self.userEnteredText!.capitalized)"
                    
                    var computer_turn = x.getComputerSmartTurn(user: a!)
                    self.speakCountry(country: "I say \(computer_turn)")
                    self.computerChance.text = "Computer said \(computer_turn.capitalized)"
                    self.timer.invalidate()
                    self.timer_counter = 0
                    self.createTimer()
                    self.country = a!
                    
                    self.deleteCountry(country: a!)
                    
                }
                else {
                    self.createAlert(message: "Country name invalid. (Remember you have to think of a country that begins with the last letter of country given by the computer.")
                }
                
                
               
            }
            else {
                self.createAlert(message: "Oops! Country does not exist! Please try again.")
            }
            
            
            
            
            
            
        })
        
        let dismissAction = UIAlertAction(title: "Dismiss", style: .default, handler: nil)
        
        alert.addAction(saveAction)
        alert.addAction(dismissAction)
        alert.addTextField(configurationHandler: {(textField:UITextField!) -> Void in
            
            textField.placeholder = "Enter Country"
        })
        
        
        
        
        
        
        
        self.present(alert, animated: true, completion: nil)
        
    
    }
    
    
    func dismissGame() {
    }
    
    
    
    @IBAction func typeAction(_ sender: UIButton) {
        createAlertWithText()
    }
    
    
    
    
    func getRandomCountry() -> String? {
        let url = createUrl(what: Command.start_game.rawValue)
        Alamofire.request(url).responseJSON {response in
            if response.result.isSuccess {
                if (response.response?.statusCode == 200) {
                    
                    let json = response.result.value as! NSDictionary
                    let data = json.object(forKey: "name") as! String
                    self.country = data
                }
            }
        }
        
        if self.country != nil {
            return self.country
        }
        else {
            return nil
        }
        
    }
    
    func createAlert(message:String) {
        let alert = UIAlertController(title: message, message: nil, preferredStyle: .alert)
        
        alert.addAction((UIAlertAction(title: "Ok", style: .default, handler: nil)))
        
        self.present(alert, animated: true, completion: nil)
        
        
    }
    
    
    
    func requestToLoadData() {
        let url = createUrl(what:Command.displayData.rawValue)
        
        if countriesData.count == 0 {
            print(url)
            
            
            Alamofire.request(url).responseJSON {response in
                if response.result.isSuccess {
                    if (response.response?.statusCode == 200) {
                        
                        let json = response.result.value as! NSDictionary
                        let data = json.object(forKey: "data") as! Array<String>
                        for i in data {
                            self.countriesData.append((i))
                        }
                        
                        print (self.countriesData.count)
                        
                        self.controlsStackView.isHidden = false
                        SwiftSpinner.hide()
                        print (self.countriesData.count)
                        Chirp.sharedManager.playSound(fileName: "start.mp3")
                        self.loaded = true
                        
                        if self.controlsStackView.isHidden == false {
                            
                            var x = CountryThinker(data: self.countriesData)
                            var a = x.pickRandomCountry()
                            
                            // Setting country
                            self.country = a
                            
                            self.computerChance.textColor = UIColor.black
                            self.computerChance.text="Computer says \(a.capitalized)"
                            self.countriesData.remove(at: self.countriesData.index(of: self.country)!)
                            print ("Removed country: \(self.country!)")
                            self.createTimer()
                        }
                        
                    }
                        
                    else {
                        self.createAlert(message: "There was an error in retreiving the data.[ Status Code != 200]")
                        self.dismiss(animated: true, completion: nil)
                        self.loaded = false
                        
                        
                    }
                }
                else {
                    self.createAlert(message: "There was an error in retreiving the data. Please check your connection")
                    self.dismiss(animated: true, completion: nil)
                    
                    self.loaded = false
                    
                    
                }
            }
        }
            
        else {
            
            var x = CountryThinker(data: self.countriesData)
            var a = x.pickRandomCountry()
            
            self.country = a
            
            self.computerChance.textColor = UIColor.black
            self.computerChance.text="Computer says \(a.capitalized)"
            
            
            
            
            
        }
        
        
    }
    

    func createFinishAlert(message:String){
        let alert = UIAlertController(title: message, message: nil, preferredStyle: .alert)
        let action = UIAlertAction(title: "Exit Game", style: .default, handler: { action in
            
            Chirp.sharedManager.playSound(fileName: "gameOver")
            self.dismiss(animated: true, completion: nil)
        })
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    @IBAction func goBackAction(_ sender: Any) {
        createFinishAlert(message: "Warning! Game progress will be lost.")
    }
    
    
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    
    @IBOutlet weak var speakButton: UIButton!
    
    
    
    func startRecording() {
        
        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }
        
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(AVAudioSessionCategoryRecord)
            try audioSession.setMode(AVAudioSessionModeMeasurement)
            try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        } catch {
            print("audioSession properties weren't set because of an error.")
        }
        
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        
        guard let inputNode = audioEngine.inputNode else {
            fatalError("Audio engine has no input node")
        }
        
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
        }
        
        recognitionRequest.shouldReportPartialResults = true
        
        recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest, resultHandler: { (result, error) in
            
            if let result = result {
                print (result.bestTranscription.formattedString)
                var c = result.bestTranscription.formattedString
                self.userEnteredText = c
                if self.checkIfExists(name: self.userEnteredText) {
                    
                    // Thinking ability (Code changed)
                    var x = CountryThinker(data: self.countriesData)
                    var a = x.validateEnteredCountry(beforeCountry: self.country, enteredCountry: self.userEnteredText)
                    if a != nil {
                        self.userChance.text = "You say \(self.userEnteredText!.capitalized)"
                        
                        var computer_turn = x.getComputerSmartTurn(user: a!)
                        self.speakCountry(country: "I say \(computer_turn)")
                        self.computerChance.text = "Computer said \(computer_turn.capitalized)"
                        self.timer.invalidate()
                        self.timer_counter = 0
                        self.createTimer()
                        self.country = a!
                        
                        self.deleteCountry(country: a!)
                        
                    }
                    else {
                        self.createAlert(message: "Country name invalid. (Remember you have to think of a country that begins with the last letter of country given by the computer.")
                    }
                    
                    
                    
                }
                else {
                    self.createAlert(message: "Oops! Country does not exist! Please try again.")
                }
                // Setting Country
            }
            
            
        
        })
        
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recognitionRequest?.append(buffer)
        }
        
        audioEngine.prepare()
        
        do {
            try audioEngine.start()
        } catch {
            print("audioEngine couldn't start because of an error.")
        }
        
        Toast(text: "Speak Now!").show()
        
    }
    
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            speakButton.isEnabled = true
        } else {
            speakButton.isEnabled = false
        }
    }
    @IBAction func speakTheCountry(_ sender: Any) {
        speechRecognizer?.delegate = self
        
        SFSpeechRecognizer.requestAuthorization { (authStatus) in  //4
            
            var isButtonEnabled = false
            
            switch authStatus {  //5
            case .authorized:
                isButtonEnabled = true
                
            case .denied:
                isButtonEnabled = false
                print("User denied access to speech recognition")
                
            case .restricted:
                isButtonEnabled = false
                print("Speech recognition restricted on this device")
                
            case .notDetermined:
                isButtonEnabled = false
                print("Speech recognition not yet authorized")
            }
            
            OperationQueue.main.addOperation() {
                self.speakButton.isEnabled = isButtonEnabled
            }
        }
        
        
        if audioEngine.isRunning {
            audioEngine.stop()
            recognitionRequest?.endAudio()
            speakButton.isEnabled = false
        } else {
            startRecording()
        }
        
        
        
    }
    
    
    
    
    
}
