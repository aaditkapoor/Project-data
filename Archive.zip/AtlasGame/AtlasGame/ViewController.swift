//
//  ViewController.swift
//  AtlasGame
//
//  Created by Aadit Kapoor on 6/4/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit
import Alamofire
import Toaster

class ViewController: UIViewController {
    
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    var loaded:Bool = false
    var countriesData:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        activityIndicator.isHidden = true
    }
    
  
    
    
    func createFinishAlert(message:String){
        let alert = UIAlertController(title: message, message: nil, preferredStyle: .alert)
        let action = UIAlertAction(title: "Let's Play", style: .default, handler: nil)
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
    }
    
    private func present(alert: UIAlertController, animated flag: Bool, completion: (() -> Void)?) -> Void {
        UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: flag, completion: completion)
    }
    
    @IBAction func startGameAction(_ sender: UIButton){
    }
    
}
