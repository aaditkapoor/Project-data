from django.http import HttpResponse
from .models import Name
import os
import csv
import random
import json
import time


# Let us start small <excluding cities> for database server space.

"""
reader = csv.reader(f)
        for row in reader:
            _, created = Names.objects.get_or_create(
                name=row[1]
                )"""

def readCSV():
	start = time.clock()
	workpath = os.path.dirname(os.path.abspath(__file__)) #Returns the Path your .py file is in
	with open(os.path.join(workpath, 'countries.csv'),"r") as f:
		read = csv.reader(f)
		for row in read:
			print "Created for countries", row[1]
			_,created = Name.objects.get_or_create(name=row[1].lower())
	end = time.clock()

	print "Took: ", start-end

def readCSVCities():
	start = time.clock()

	workpath = os.path.dirname(os.path.abspath(__file__)) #Returns the Path your .py file is in
	with open(os.path.join(workpath, 'world-cities.csv'),"r") as f:
		read = csv.reader(f)
		for row in read:
			print "Created for cities",row[0]
			_,created = Name.objects.get_or_create(name=row[0].lower())
	end = time.clock()
	print "Took: ", start-end
def load_cities(request):
	readCSVCities()
	return HttpResponse("Done loading cities")

def loadData(request):
	objs = Name.objects.all()
	data = []
	for i in objs:
		data.append(i.name)

	return in_json(data, "data")
		

def in_json(what,key):
	return HttpResponse(list(json.dumps({key:what}, sort_keys=True, indent=4)),content_type="application/json")


def delete_from_main_database(name):
	name = name.encode("UTF-8")
	print ("Deleted:",name)
	instance = Name.objects.get(name=name).delete()


def load(request):
	Name.objects.all().delete()
	readCSV()
	return HttpResponse("LOADING DATA COMPLETE")




def startGame(request):
	all_data = Name.objects.all()
	random_object = random.choice(all_data)
	name = random_object.name
	delete_from_main_database(name)
	return in_json(name, "name")

def moveForward(request):
	user_input = request.GET.get("user_input","")
	user_input = user_input.encode("UTF-8")
	user_input = user_input.lower()
	if user_input:
		if Name.objects.filter(name=str(user_input)).exists():
			to_show = ""
			random_object_to_show = random.choice(Name.objects.filter(name__startswith=str(user_input[0])))
			name = random_object_to_show.name
			delete_from_main_database(name)
			delete_from_main_database(user_input)
			return in_json(name, "name")
		else:
			return in_json("name used or does not exists.","error")
	else:
		return in_json("no input","error")

	






